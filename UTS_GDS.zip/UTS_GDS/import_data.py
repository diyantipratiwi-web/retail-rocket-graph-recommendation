import os
import sys
import pandas as pd
from neo4j import GraphDatabase
from tqdm import tqdm

URI = "neo4j://127.0.0.1:7687"
USER = "neo4j"
PASSWORD = "12345678" 

def create_constraints(session):
    try:
        session.run("CREATE CONSTRAINT FOR (v:Visitor) REQUIRE v.visitorid IS UNIQUE")
        session.run("CREATE CONSTRAINT FOR (i:Item) REQUIRE i.itemid IS UNIQUE")
        print("Constraint berhasil dibuat! Proses impor akan jauh lebih cepat.")
    except Exception as e:
        print("Constraint sudah ada atau terjadi peringatan kecil (Aman untuk dilanjutkan).")

def import_batch(tx, batch):
    cypher_query = """
    UNWIND $batch AS row
    MERGE (v:Visitor {visitorid: row.visitorid})
    MERGE (i:Item {itemid: row.itemid})
    WITH v, i, row
    CALL {
        WITH v, i, row
        WITH v, i, row WHERE row.event = 'view'
        CREATE (v)-[:VIEWED {timestamp: row.timestamp}]->(i)
        UNION ALL
        WITH v, i, row
        WITH v, i, row WHERE row.event = 'addtocart'
        CREATE (v)-[:ADDED_TO_CART {timestamp: row.timestamp}]->(i)
        UNION ALL
        WITH v, i, row
        WITH v, i, row WHERE row.event = 'transaction'
        CREATE (v)-[:BOUGHT {timestamp: row.timestamp, transactionid: row.transactionid}]->(i)
    }
    """
    tx.run(cypher_query, batch=batch)

def main():
    csv_file_path = "events.csv" 
    
    if not os.path.exists(csv_file_path):
        print(f"Error: File '{csv_file_path}' tidak ditemukan!")
        sys.exit(1)

    try:
        driver = GraphDatabase.driver(URI, auth=(USER, PASSWORD))
        driver.verify_connectivity()
    except Exception as e:
        print(f"Gagal terhubung ke database: {e}")
        sys.exit(1)

    batch_size = 10000 
    chunks = pd.read_csv(csv_file_path, chunksize=batch_size) 
    
    total_rows = sum(1 for row in open(csv_file_path, 'r')) - 1
    total_chunks = (total_rows // batch_size) + 1 

    print("Memulai proses impor data ke Neo4j...")
    
    with driver.session() as session:
        # PANGGIL FUNGSI CONSTRAINT
        create_constraints(session)
        
        for chunk in tqdm(chunks, total=total_chunks, desc="Mengimpor Batch Data"): 
            chunk["transactionid"] = chunk["transactionid"].fillna("").astype(str) 
            records = chunk.to_dict(orient="records") 
            session.execute_write(import_batch, records) 
            
    driver.close() 
    print("Proses impor berhasil!")

if __name__ == "__main__":
    main()